export const environment = {
    apiPrefix: 'api',
    apiRoot: 'https://sampledev-api.azurewebsites.net',
    envName: 'prod',
    production: true
};
