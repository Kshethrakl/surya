export interface IHomePageViewModel {
    
}