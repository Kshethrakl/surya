﻿namespace Sample.Core.Modules
{
    public interface ILamaWebModule : ILamaModule
    {

    }
}
